'''This is an example of a queuing loop that executes all submitted items on
the same thread it is run from. It also supports returning futures for
`SelectRead` and `SelectWrite` objects, which are thin wrappers around any
object that may be passed to `select.select`.
'''

import collections
import concurrent.futures
import select
import threading
from contexts import async, with_options, CallableContext

# These types are supported by SingleThreadContext.get_future_for
SelectRead = collections.namedtuple('SelectRead', ['fd'])
SelectWrite = collections.namedtuple('SelectWrite', ['fd'])

class SingleThreadContext(CallableContext):
    '''Represents a context for the current thread where callables may be
    executed.
    '''
    def __init__(self):
        self._terminate = False
        self._exit_code = None
        self._exit_exception = None
        self._main_thread = None
        self._read_sockets = {}
        self._write_sockets = {}
        self._signal = threading.Condition()
        self._queue = collections.deque()

    def submit(self, callable, *args, **kwargs):
        '''Adds a callable to invoke within this context.'''
        with self._signal:
            self._queue.append((callable, args, kwargs))
            self._signal.notify_all()

    def get_future_for(self, obj):
        '''Returns futures for socket objects.'''
        if isinstance(obj, (SelectRead, SelectWrite)):
            fd = obj[0]
            if fd in self._read_sockets or fd in self._write_sockets:
                # We cannot wait on the same file descriptor multiple times, but maybe the caller can.
                return None

            f = concurrent.futures.Future()
            f.set_running_or_notify_cancel()
            if isinstance(obj, SelectRead):
                self._read_sockets[fd] = f
            else:
                self._write_sockets[fd] = f
            return f
        return None

    def exit_with_future(self, future):
        '''Terminates the context, returning the result (or raising
        the exception) from the provided future.
        '''
        with self._signal:
            self._terminate = True
            self._exit_exception = future.exception()
            if not self._exit_exception:
                self._exit_code = future.result()
            self._signal.notify_all()

    def run(self, callable=None, *args, **kwargs):
        '''Starts the context. This method does not return until `exit` is
        called. The return value is the object passed in the call to `exit`.
        
        If `callable` is provided it will be called with `args` and `kwargs`.
        If it returns a `concurrent.futures.Future` then the context will be
        terminated when that future completes. The return value is the result
        of the future.
        '''
        
        previous_context = CallableContext.set_current(self)
        
        if callable:
            future = callable(*args, **kwargs)
            # Add a callback if the returned object looks like a future.
            # If not, we silently forget about it.
            try:
                add_done_callback = future.add_done_callback
            except AttributeError:
                pass
            else:
                if hasattr(add_done_callback, "__call__"):
                    # If the future is already complete, the callback
                    # will be invoked immedately.
                    add_done_callback(self.exit_with_future)

            if self._terminate:
                # May have terminated already if callable returned a
                # completed future.
                return self._exit_code
    
        def _wait_condition():
            return self._terminate or self._queue or self._read_sockets or self._write_sockets

        # Main message loop
        while True:
            with self._signal:
                callable = None
                self._signal.wait_for(_wait_condition)

                if self._terminate:
                    break

                if self._read_sockets or self._write_sockets:
                    # Because we have no signal for another queued object, we will simply use a short
                    # timeout if _queue is not ready, and no timeout if it is.
                    # To do this properly would need a fake socket object on Windows (or any file
                    # descriptor on Linux) that we can make ready if a completion occurs.
                    ready_read, ready_write, _ = select.select(
                        self._read_sockets.keys(),
                        self._write_sockets.keys(),
                        [],
                        0 if self._queue else 0.01
                    )
                    for rr in ready_read:
                        future = self._read_sockets.pop(rr)
                        future.set_result(rr)
                    for rw in ready_write:
                        future = self._write_sockets.pop(rw)
                        future.set_result(rw)
                    if ready_read or ready_write:
                        continue

                if self._queue:
                    callable, args, kwargs = self._queue.popleft()

            if callable:
                # Call the task outside of the lock
                callable(*args, **kwargs)

        CallableContext.set_current(previous_context)

        if self._exit_exception:
            raise self._exit_exception
        return self._exit_code
