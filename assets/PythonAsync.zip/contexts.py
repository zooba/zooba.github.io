import collections
import concurrent.futures
import functools
import types
import threading

_tls = threading.local()

class CallableContext:
    '''Represents a context, such as a thread or process, in which callables
    may be executed. An awaiter context differs from a thread or process pool
    in that execution always occurs within the context regardless of the
    source of the callable.

    A common usage is to ensure that `concurrent.futures.Future` objects invoke
    their callback in the same context it was started from::
        executor = ThreadPoolExecutor(max_workers=5)
        future = executor.submit(perform_calculation)
        
        # Must capture `context` outside of the handler
        context = awaiters.CallableContext.get_current()
        future.add_done_handler(lambda f: context.submit(print, f.result()))

    If no context has been set up, `get_current` will return None.

    A context may be manually set up by using a subclass of `CallableContext`
    such as `ThreadContext`::
        context = awaiters.ThreadContext()

        def main():
            # This method is within the context of the current thread

            ctxt = awaiters.CallableContext.get_current()
            # ctxt is context == True when called from this thread.

            f = executor.submit(lambda: awaiters.CallableContext.get_current())
            # f.result() is None == true when called from another thread

        context.run(main)
    '''

    @staticmethod
    def get_current():
        '''Returns the current callable context if one exists. This should be
        captured and passed to an asynchronous operation so that it can use the
        `submit` or `post` methods to execute code in the original context.

        If this returns ``None``, there is no context available.
        '''
        try:
            context = _tls.current_context
        except AttributeError:
            _tls.current_context = context = CallableContext()
        
        return context

    @staticmethod
    def set_current(context):
        '''Sets the current context and returns the previous one.'''
        try:
            old_context = _tls.current_context
        except AttributeError:
            old_context = None
        _tls.current_context = context
        return old_context

    def submit(self, callable, *args, **kwargs):
        '''Adds a callable to invoke within a context. This method returns
        immediately and any exceptions will be raised in the target context.

        This method has no return value.

        The default implementation executes the callable immediately.
        '''
        callable(*args, **kwargs)   # The default implementation executes the 
                                    # callable synchronously.

    def get_future_for(self, obj):
        '''Returns a `Future` that will be updated when `obj` is ready or is
        canceled. The value of the `Future`'s ``result()`` is a reference to
        `obj`.
        
        This function returns ``None`` if the context does not
        recognize or cannot handle `obj`, and the caller is then responsible
        for determining when it becomes ready.
        '''
        return None                 # The default implementation cannot handle
                                    # any waitable objects.

class _Awaiter:
    '''Implements the callback behavior of functions wrapped with `async`.'''
    def __init__(self, generator, final_future):
        self.generator = generator                  # This generator contains "user" code.
        self.final_future = final_future            # This was returned to the caller.
        self.target_context = CallableContext.get_current() # Unless told otherwise, we will keep
                                                            # running the generator's code in this
                                                            # context.
        if self.final_future.set_running_or_notify_cancel():
            self._step(None)            # Async operations start "hot" - the first step has already
                                        # run. This lets us complete immediately if nothing is
                                        # yielded.
    
    def __call__(self, prev_future):
        if getattr(prev_future, '_callback_context_patched', False):
            # If with_options() was used (see below), we are already in the correct context.
            return self._step(prev_future)

        self.target_context.submit(self._step, prev_future) # Invoke the next step in the 
                                                            # original context.
        
    def _step(self, prev_future):
        result, ex = None, None
        if prev_future:
            ex = prev_future.exception()        # Get the exception without raising it.
            if not ex:
                result = prev_future.result()   # Only get the result if there was no error.

        try:
            if ex:
                next_future = self.generator.throw(ex)  # Pass errors back into the generator
                                                        #so they can be handled.
            else:
                next_future = self.generator.send(result)   # Pass results back in.
            
            next_future.add_done_callback(self)         # We only reach here if something was
                                                        # yielded, so assume that it was a Future.
        except StopIteration as si:
            self.final_future.set_result(si.value)      # Complete the future we returned originally.
        except BaseException as ex:
            self.final_future.set_exception(ex)         # Exceptions within __next__ have to
                                                        # propagate through this Future, since
                                                        # there is nowhere to pass them back in.


def async(fn):
    '''Decorator to wrap a generator as an asynchronous function returning a
    `concurrent.futures.Future` object.

    When called, the generator will execute up to the first yield statement.
    The yielded value must be a `concurrent.futures.Future` object, which may
    be obtained from any source. When the future completes, its result is sent
    into the generator. For example::
        from concurrent.futures import ThreadPoolExecutor
        from urllib.request import urlopen
        
        executor = ThreadPoolExecutor(max_workers=5)

        def load_url(url):
            return urlopen(url).read()

        @async
        def get_image_async(url):
            buffer = yield executor.submit(load_url, url)
            return Image(buffer)

        def main(image_uri):
            img_future = get_image_async(image_uri)
            # perform other tasks while the image is downloading
            img = img_future.result()

        main("http://www.python.org/images/python-logo.gif")
    '''
    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        result = fn(*args, **kwargs)
        final_future = concurrent.futures.Future()
        if isinstance(result, types.GeneratorType):
            _Awaiter(result, final_future)  # Initialising _Awaiter is sufficient to start the 
                                            # operation running and it will notify final_future 
                                            # when it is complete.
        else:
            final_future.set_result(fn(*args, **kwargs))    # Non-generator methods still return
                                                            # a Future for consistency.
        return final_future
    return wrapper

def _alternate_invoke_callbacks(self, context):
    for callback in self._done_callbacks:
        try:
            if context:
                context.submit(callback, self)
            else:
                callback(self)
        except Exception:
            from concurrent.futures._base import LOGGER
            LOGGER.exception('exception calling callback for %r', self)


def with_options(future, **options):
    # Just monkey patching the Future. There are no doubt better ways to
    # achieve the same result, but without modifying Future's definition this
    # is easiest.
    try:
        callback_context = options['callback_context']
    except KeyError:
        pass
    else:
        future._invoke_callbacks = lambda: _alternate_invoke_callbacks(future, callback_context)
        future._callback_context_patched = True
    
    # Again, there may be a more appropriate way to implement this option, but
    # forcing a call to `result` is good enough for this example.
    if options.get('always_raise', False):
        future.add_done_callback(concurrent.futures.Future.result)
    
    return future
