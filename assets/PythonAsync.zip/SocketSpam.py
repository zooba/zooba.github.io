# Based on the example by Greg Ewing
#   http://www.cosc.canterbury.ac.nz/greg.ewing/python/tasks/SimpleScheduler.html

from contexts import CallableContext, async
from socket import *
from SingleThreadContext import *

port = 4200

@async
def sock_accept_async(sock):
    f = CallableContext.get_current().get_future_for(SelectRead(sock))
    if f:
        return (yield f).accept()
    else:
        # This is the fallback option for when the current context does not support `SelectRead`
        # objects. It should probably use a CPU thread rather than blocking the caller.
        return sock.accept()

@async
def sock_readline_async(sock):
    buf = b""
    while buf[-1:] != b"\n":
        f = CallableContext.get_current().get_future_for(SelectRead(sock))
        if f:
            data = (yield f).recv(1024)
            # Uncomment this exception to see how with_options(f, always_raise=True) handles
            # errors in async functions that are not waited upon.
            #raise Exception("EPIC FAIL!")
        else:
            # This is the fallback option for when the current context does not support `SelectRead`
            # objects. It should probably use a CPU thread rather than blocking the caller.
            data = sock.recv(1024)
        if not data:
            break
        buf += data
    if not buf:
        sock.close()
    return buf.decode(errors='ignore')

@async
def sock_write_async(sock, data):
    data = data.encode()
    while data:
        f = CallableContext.get_current().get_future_for(SelectWrite(sock))
        if f:
            n = (yield f).send(data)
        else:
            # This is the fallback option for when the current context does not support `SelectWrite`
            # objects. It should probably use a CPU thread rather than blocking the caller.
            n = sock.send(data)
        data = data[n:]

@async
def listener():
    lsock = socket(AF_INET, SOCK_STREAM)
    lsock.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
    lsock.bind(("", port))
    lsock.listen(5)
    while 1:
        csock, addr = yield sock_accept_async(lsock)
        print("Listener: Accepted connection from", addr)
        yield sock_write_async(csock, "Welcome to my Spam Machine!\r\n")

        # Calling without yielding the returned future runs multiple tasks in parallel
        # But we apply the `always_raise` option to the future to ensure we hear about
        # any errors. A more robust program would handle them in a better way than this.
        with_options(handler(csock), always_raise=True)

@async
def handler(sock):
    while 1:
        line = yield sock_readline_async(sock)
        if not line:
            break
        try:
            n = parse_request(line)
            yield sock_write_async(sock, "100 SPAM FOLLOWS\r\n")
            for i in range(n):
                yield sock_write_async(sock, "spam glorious spam\r\n")
        except BadRequest:
            yield sock_write_async(sock, "400 WE ONLY SERVE SPAM\r\n")

class BadRequest(Exception):
    pass

def parse_request(line):
    tokens = line.split()
    if len(tokens) != 2 or tokens[0] != "SPAM":
        raise BadRequest
    try:
        n = int(tokens[1])
    except ValueError:
        raise BadRequest
    if n < 1:
        raise BadRequest
    return n


SingleThreadContext().run(listener)

