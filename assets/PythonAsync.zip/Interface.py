class CallableContext:
    '''Represents a context, such as a thread or process, in which callables
    may be executed. A callable context differs from a thread or process pool
    in that execution always occurs within the context regardless of the source
    of the callable.'''
    
    ## Static Methods
    
    get_current() -> CallableContext or subclass
    '''Returns the current context. Never returns None, but may return a very
    naive context if none has been set.'''

    set_current(context) -> CallableContext or subclass, None
    '''Returns the previous context, which should be restored when the new
    context becomes invalid.'''

    ## Instance Methods
    submit(self, callable, *args, **kwargs) -> None
    '''Adds a callable to invoke within a context. This method returns
    immediately and any exceptions will be raised in the target context.'''
    
    get_future_for(self, obj) -> Future, None
    '''Returns a `Future` that will be updated when `obj` is ready or is
    cancelled. The value of the returned Future's ``result()`` is a reference
    to `obj`.'''

def async(function) -> (`function` -> Future)
    '''Returns an async function for `function`.
    
    An async function always returns a `Future`, which must be used to obtain
    the value returned from the wrapped function.
    
    If the wrapped function is a generator, it must only yield instances of
    `Future`. The next step of the generator will occur after the yielded
    `Future` completes.
    
    If the wrapped function is not a generator, the returned `Future` already
    has the result and will not block when ``result()`` is called.'''

def with_options(future, [callback_context]) -> Future
    '''Adds options to a `Future`.
    
    These may be used with `async` to adjust the treatment of `future`. Calling
    this function with default parameters is a no-operation and `future` is
    returned unmodified.
    
    The current options are:
      continuation_context
        Specifies the `CallableContext` where the done callback will be
        executed. If unspecified, the current context is used. Specifying
        ``None`` will execute the callback in any context. When yielding this
        future from an `async` function, this affects where the statements
        following the yield will be executed.

      always_raise [bool]
        Specifies whether the `Future` should always raise its exception,
        regardless of the context it is set in. This will occur regardless of
        other calls to ``result()`` or ``exception()``.
    '''
