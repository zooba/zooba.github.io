using System;
using System.Linq;
using FakeEALib;

namespace FakeEALib.Experiments {
    class SteadyStateGeneticAlgorithms {
        public static void Run() {
            var population = new Populations.Binary(64);
            var parents = new Populations.Binary(64);
            population.Evaluator = new Evaluators.Binary.OneMax();
            population.Sort.Add(new Sorters.FitnessProportional());
            parents.Select.Add(new Selectors.Clone());
            parents.Variation.Add(new Operators.Crossover(1, 0.98));
            parents.Variation.Add(new Operators.MutateBitflip(1.0, 1.0 / 64));
            parents.VariationMode = Operators.VariationMode.Replace;

            population.CreateRandom(100);

            population.Evaluate();
            Console.WriteLine("Iter | Best Fit | Mean Fit | Worst Fit");
            Console.WriteLine("{0} | {1} | {2} | {3}", 
                0, population.Best.Fitness, population.MeanFitness, population.Worst.Fitness);

            for (int iteration = 1; iteration <= 50; ++iteration) {
                for (int step = 0; step < 100; ++step) {
                    population.Step();
                    parents.Clear();
                    parents.AddRange(population.Take(2));
                    parents.Step();
                    population.RemoveAt(0);
                    population.RemoveAt(0);
                    population.AddRange(parents);
                    population.Evaluate();
                }

                Console.WriteLine("{0} | {1} | {2} | {3}", 
                    iteration, population.Best.Fitness, population.MeanFitness, population.Worst.Fitness);
            }

            Console.WriteLine("Best: {0} [{1}]", population.Best.Fitness, population.Best.ToString());
        }
    }
}