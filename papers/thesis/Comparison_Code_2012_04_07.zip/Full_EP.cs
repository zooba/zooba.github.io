﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FullAlgorithms {
    static class EvolutionaryProgramming {
        private class Individual : IComparable<Individual> {
            public readonly int[] Genome;
            public double Fitness;

            public Individual(int length) {
                Genome = new int[length];
            }

            public int CompareTo(Individual other) {
                return other.Fitness.CompareTo(Fitness);
            }

            public override string ToString() {
                return String.Join(", ", Genome);
            }
        }

        private static void PrintSummary(int iteration, List<Individual> indivs) {
            indivs.Sort();
            double total = 0;
            foreach (var indiv in indivs) {
                total += indiv.Fitness;
            }
            double average = total / indivs.Count;

            Console.WriteLine("{0} | {1} | {2} | {3}",
                iteration, indivs[0].Fitness, average, indivs[indivs.Count - 1].Fitness);
        }

        public static void Run() {
            var rnd = new Random();
            var population = new List<Individual>();

            for (int i = 0; i < 100; ++i) {
                var indiv = new Individual(8);
                for (int j = 0; j < indiv.Genome.Length; ++j) {
                    indiv.Genome[j] = rnd.Next(0, 26);
                }
                population.Add(indiv);
            }

            foreach (var indiv in population) {
                int total = 0;
                for (int j = 0; j < indiv.Genome.Length; ++j) {
                    total += indiv.Genome[j];
                }
                indiv.Fitness = (double)total;
            }

            Console.WriteLine("Iter | Best Fit | Mean Fit | Worst Fit");
            PrintSummary(0, population);

            for (int iteration = 1; iteration <= 50; ++iteration) {
                var offspring = new List<Individual>();
                foreach (var indiv in population) {
                    var child = new Individual(8);
                    for (int j = 0; j < indiv.Genome.Length; ++j) {
                        double prob = rnd.NextDouble();
                        if (prob < 0.25)
                            child.Genome[j] = indiv.Genome[j] + 1;
                        else if (prob < 0.5)
                            child.Genome[j] = indiv.Genome[j] - 1;
                        else
                            child.Genome[j] = indiv.Genome[j];
                    }
                    offspring.Add(child);
                }

                foreach (var indiv in offspring) {
                    int total = 0;
                    for (int j = 0; j < indiv.Genome.Length; ++j) {
                        total += indiv.Genome[j];
                    }
                    indiv.Fitness = (double)total;
                }

                population.AddRange(offspring);

                population.Sort();

                population.RemoveRange(100, population.Count - 100);

                PrintSummary(iteration, population);
            }

            Console.WriteLine("Best: {0} [{1}]", population[0].Fitness, population[0].ToString());
        }
    }
}
