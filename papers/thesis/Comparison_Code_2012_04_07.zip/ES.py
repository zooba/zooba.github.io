import math
import esec.landscape.real

def random_indiv(length=10):
    from esec.context import rand, context
    for indiv in context['random_real'](length=length, lowest=-5, highest=5):
        indiv.strategy = [rand.random() * 0.5 for _ in xrange(int(length))]
        yield indiv

def es_mutate(_source):
    from esec.context import rand
    for indiv in _source:
        n = len(indiv)
        new_strategy = []
        new_solution = []
        for (value, stddev) in zip(indiv, indiv.strategy):
            new_strategy.append(stddev * math.exp(
                rand.gauss(0, 1) * math.sqrt(4/n) + 
                rand.gauss(0, 1) / (2*n)))
            new_solution.append(value + new_strategy[-1] * rand.gauss(0, 1))
        yield type(indiv)(new_solution, indiv, strategy=new_strategy)

SYSTEM_DEFINITION = r'''
FROM random_indiv(length=2) SELECT 20 population
YIELD population

BEGIN iteration
  FROM population SELECT 40 offspring USING repeated, es_mutate

  FROM population, offspring SELECT 20 population USING best
  YIELD population
END
'''

config = {
    'system': {
        'definition': SYSTEM_DEFINITION,
        'random_indiv': random_indiv,
        'es_mutate': es_mutate,
    },
    'landscape': { 'class': esec.landscape.real.Sphere, 'parameters': 2 },
    'monitor': {
        'report': 'brief+local+time_delta',
        'summary': 'status+brief+best_genome',
        'limits': { 'iterations': 50 }
    },
}
