from esec import esdl_eval
from esec.species.tgp import Instruction

SYSTEM_DEFINITION = r'''
FROM random_tgp(instructions,deepest=15,terminals=1) SELECT (size) population
EVAL population USING eval_expression
deepest_result = 7
YIELD population

BEGIN generation
  FROM population SELECT (size) parents USING fitness_proportional
  FROM parents SELECT (size*0.9) p1, (size*0.02) p2, p3

  FROM p1 SELECT o1 USING crossover_one(deepest_result)
  FROM p2 SELECT o2 USING mutate_random(deepest_result)

  FROM o1, o2, p3 SELECT (size) population
  YIELD population
END
'''

@esdl_eval
def eval_expression(individual):
  from esec.context import rand
  error_sum = 0.0
  for _ in range(20):
    x = rand.random() * 2.0 - 1.0
    expected = x**3 + x**2 + x + 1
    actual = individual.evaluate(individual, terminals=[x])
    error_sum += (actual - expected) ** 2

  return 1.0 / (1 + error_sum)

config = {
    'system': { 
        'definition': SYSTEM_DEFINITION,
        'instructions': [
            Instruction(lambda a, b: a+b, param_count=2, name='+'),
            Instruction(lambda a, b: a-b, param_count=2, name='-'),
            Instruction(lambda a, b: a*b, param_count=2, name='*'),
            Instruction(lambda a, b: (a/b) if b else 0.0, param_count=2, name='/'),
        ],
        'size': 50
    },
    'monitor': {
        'report': 'brief+local+time_delta',
        'summary': 'status+brief+best_phenome',
        'limits': { 'iterations': 50 }
    },
}
