from __future__ import division
import re

SOURCES = [
    ('esec', "esec", '.py'),
    ('ECJ', "ECJ", '.txt'),
    ('FakeEALib', "FakeEALib\\Experiments", '.cs'),
    ('C#', "FakeEALib\\FullAlgorithms", '.cs')
]

FILES = [
    "ES",
    "EP",
    "GA",
    "DE",
    "SSGA",
    "PSO",
]

results = { }
results2 = {name : {'Lines': {}, 'Words': {}, 'UniqueWords': {}, 'Chars': {}} for name in FILES}

is_line = re.compile('.*[a-z0-9.,=]', re.IGNORECASE)
words = re.compile('([a-z]+|[0-9.]+)', re.IGNORECASE)

def get_stats(filename):
    lines = []
    with open(filename, 'r') as f:
        for line in f:
            line = line.strip(' \t\r\n')
            if not line.startswith(('#', '//')):
                lines.append(line)
    
    char_count = 0
    line_count = 0
    all_words = set()
    word_count = 0
    for line in lines:
        for c in line:
            if c not in ' \t':
                char_count += 1
        if is_line.match(line):
            line_count += 1
        found_words = words.findall(line)
        word_count += len(found_words)
        all_words.update(found_words)
    
    return line_count, word_count, len(all_words), char_count

for name in FILES:
    for category, dir, extension in SOURCES:
        stats = get_stats(dir + '\\' + name + extension)
        results[name + "," + category] = stats
        results2[name]['Lines'][category] = stats[0]
        results2[name]['Words'][category] = stats[1]
        results2[name]['UniqueWords'][category] = stats[2]
        results2[name]['Chars'][category] = stats[3]

print 'Algorithm,Value,' + ','.join(i[0] for i in SOURCES) + ',' + ','.join(i[0] + ' (rel)' for i in SOURCES)
for name in FILES:
    stats = results2[name]
    for part in ('Lines', 'Words', 'UniqueWords', 'Chars'):
        line = [name, part]
        for category, _, _ in SOURCES:
            line.append(str(stats[part][category]))
        for category, _, _ in SOURCES:
            line.append(str(stats[part][category] / stats[part][SOURCES[0][0]]))
        print ','.join(line)
