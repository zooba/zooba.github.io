import esec.landscape.real

def random_particle(length=10, low_limit=0, high_limit=1):
    from esec.context import rand, context
    for indiv in context['random_real'](length=length, lowest=low_limit, highest=high_limit):
        indiv.strategy = [0] * int(length)
        yield indiv

def update_velocity(_source, global_best=None, low_limit=-100, high_limit=100,
                    c1=2, c2=2):
    from esec.context import rand
    g_best = global_best[0]
    for indiv, p_best in _source:
        new_velocity = []
        for (x, v, p_i, p_g) in zip(indiv, indiv.strategy, p_best, g_best):
            r1 = rand.random()
            r2 = rand.random()

            new_v = v + c1*r1*(p_i-x) + c2*r2*(p_g-x)

            if new_v < low_limit:
                new_velocity.append(low_limit)
            elif high_limit < new_v:
                new_velocity.append(high_limit)
            else:
                new_velocity.append(new_v)

        yield type(indiv)(indiv.genome, indiv, strategy=new_velocity)

def update_position(_source, low_limit=-100, high_limit=100, bounce=False):
    for indiv in _source:
        new_position = []
        new_velocity = []
        for x, v in zip(indiv.genome, indiv.strategy):
            new_x = x + v
            new_v = v
            if bounce:
                if new_x < low_limit:
                    new_x = 2 * low_limit - new_x
                    new_v = -v
                elif high_limit < new_x:
                    new_x = 2 * high_limit - new_x
                    new_v = -v
            new_position.append(new_x)
            new_velocity.append(new_v)
        
        yield type(indiv)(new_position, indiv, strategy=new_velocity)

SYSTEM_DEFINITION = r'''
FROM random_particle(length=2, low_limit=-5, high_limit=5) SELECT 50 swarm
FROM swarm SELECT p_bests
YIELD swarm

BEGIN iteration
  FROM swarm SELECT 1 g_best USING best
  JOIN swarm, p_bests INTO particles_with_pbest
  FROM particles_with_pbest SELECT swarm USING \
       update_velocity(global_best=g_best, low_limit=-100, high_limit=100), \
       update_position(low_limit=-5, high_limit=5, bounce)
  YIELD swarm
END
'''

config = {
    'system': {
        'definition': SYSTEM_DEFINITION,
        'random_particle': random_particle,
        'update_velocity': update_velocity,
        'update_position': update_position,
    },
    'landscape': { 'class': esec.landscape.real.Sphere, 'parameters': 2 },
    'monitor': {
        'report': 'brief+local+time_delta',
        'primary': 'swarm',
        'summary': 'status+brief+best_genome',
        'limits': { 'iterations': 50 }
    },
}
