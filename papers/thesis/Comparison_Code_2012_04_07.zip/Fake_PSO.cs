using System;
using System.Collections.Generic;
using FakeEALib;

namespace FakeEALib.Experiments {
    class ParticleSwarmOptimisation {
        public static void Run() {
            var swarm = new Populations.RealWithStrategy(2, -5.0, 5.0, 0.0, 0.0);
            var pBests = new Populations.RealWithStrategy(2, -5.0, 5.0, 0.0, 0.0);
            swarm.Evaluator = new Evaluators.Real.Sphere();

            swarm.Variation.Add(new UpdateVelocity(-100.0, 100.0, pBests));
            swarm.Variation.Add(new UpdatePosition(-5.0, 5.0, true));
            swarm.VariationMode = Operators.VariationMode.Replace;

            swarm.CreateRandom(50);
            swarm.Evaluate();
            pBests.AddClonedRange(swarm);

            swarm.Evaluate();
            Console.WriteLine("Iter | Best Fit | Mean Fit | Worst Fit");
            Console.WriteLine("{0} | {1} | {2} | {3}", 
                0, swarm.Best.Fitness, swarm.MeanFitness, swarm.Worst.Fitness);

            for (int iteration = 1; iteration <= 50; ++iteration) {
                swarm.Step();
                swarm.Evaluate();

                for (int i = 0; i < swarm.Count; ++i) {
                    if (swarm[i].Fitness > pBests[i].Fitness) {
                        pBests[i] = swarm[i].Clone();
                    }
                }

                Console.WriteLine("{0} | {1} | {2} | {3}", 
                    iteration, swarm.Best.Fitness, swarm.MeanFitness, swarm.Worst.Fitness);
            }

            Console.WriteLine("Best: {0} [{1}]", swarm.Best.Fitness, swarm.Best.ToString());
        }
    }

    class UpdatePosition : Operators.IOperator {
        public double LowLimit { get; private set; }
        public double HighLimit { get; private set; }
        public bool Bounce { get; private set; }
        
        public UpdatePosition(double lowLimit, double highLimit, bool bounce) {
            LowLimit = lowLimit;
            HighLimit = highLimit;
            Bounce = bounce;
        }

        public void Vary(IList<Populations.IIndividual> source, int index) {
            var indiv = (Populations.IRealIndividualWithStrategy)source[index];

            for (int i = 0; i < indiv.Count; ++i) {
                indiv[i] += indiv.Strategy[i];
                if (Bounce && indiv[i] < LowLimit) {
                    indiv[i] = 2 * LowLimit - indiv[i];
                    indiv.Strategy[i] = -indiv.Strategy[i];
                } else if (Bounce && indiv[i] > HighLimit) {
                    indiv[i] = 2 * HighLimit - indiv[i];
                    indiv.Strategy[i] = -indiv.Strategy[i];
                }
            }
        }
    }

    class UpdateVelocity : Operators.IOperator {
        public double LowLimit { get; private set; }
        public double HighLimit { get; private set; }
        public Populations.IPopulation PersonalBests { get; private set; }
        
        public UpdateVelocity(double lowLimit, double highLimit, Populations.IPopulation pBests) {
            LowLimit = lowLimit;
            HighLimit = highLimit;
            PersonalBests = pBests;
        }

        public void Vary(IList<Populations.IIndividual> source, int index) {
            var indiv = (Populations.IRealIndividualWithStrategy)source[index];
            var pBest = (Populations.IRealIndividualWithStrategy)PersonalBests[index];
            var gBest = (Populations.IRealIndividualWithStrategy)PersonalBests.Best;

            for (int i = 0; i < indiv.Count; ++i) {
                indiv.Strategy[i] += 2 * Random.Uniform(0, 1) * (pBest[i] - indiv[i]) +
                                     2 * Random.Uniform(0, 1) * (gBest[i] - indiv[i]);
                if (indiv.Strategy[i] < LowLimit) {
                    indiv.Strategy[i] = LowLimit;
                } else if (indiv.Strategy[i] > HighLimit) {
                    indiv.Strategy[i] = HighLimit;
                }
            }
        }
    }
}
