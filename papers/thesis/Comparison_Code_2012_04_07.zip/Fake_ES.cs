using System;
using System.Collections.Generic;
using FakeEALib;

namespace FakeEALib.Experiments {
    class EvolutionStrategy {
        public static void Run() {
            var population = new Populations.RealWithStrategy(10, -5.0, 5.0, 0.0, 0.5);
            var offspring = new Populations.RealWithStrategy(10, -5.0, 5.0, 0.0, 0.5);
            population.Evaluator = new Evaluators.Real.Sphere();

            offspring.Select.Add(new Selectors.Clone());
            offspring.Variation.Add(new MutateES());
            offspring.VariationMode = Operators.VariationMode.Replace;
            offspring.Sort.Add(new Sorters.Best());
            offspring.Filter.Add(new Filters.Truncate(20));
            offspring.Evaluator = population.Evaluator;

            population.CreateRandom(20);

            population.Evaluate();
            Console.WriteLine("Iter | Best Fit | Mean Fit | Worst Fit");
            Console.WriteLine("{0} | {1} | {2} | {3}", 
                0, population.Best.Fitness, population.MeanFitness, population.Worst.Fitness);

            for (int iteration = 1; iteration <= 50; ++iteration) {
                population.Evaluate();
                offspring.Clear();
                offspring.AddClonedRange(population);
                offspring.AddClonedRange(population);
                offspring.Vary();
                offspring.AddRange(population);
                offspring.Evaluate();
                offspring.SortFilter();

                population.Clear();
                population.AddRange(offspring);

                Console.WriteLine("{0} | {1} | {2} | {3}", 
                    iteration, population.Best.Fitness, population.MeanFitness, population.Worst.Fitness);
            }

            Console.WriteLine("Best: {0} [{1}]", population.Best.Fitness, population.Best.ToString());
        }
    }

    class MutateES : Operators.IOperator {
        public void Vary(IList<Populations.IIndividual> source, int index) {
            var indiv = (Populations.IRealIndividualWithStrategy)source[index];

            for (int i = 0; i < indiv.Count; ++i) {
                indiv.Strategy[i] *= Math.Exp(
                    Random.Normal() * Math.Sqrt(4.0 / indiv.Count) +
                    Random.Normal() / (2.0 * indiv.Count));

                indiv[i] += indiv.Strategy[i] * Random.Normal();
            }
        }
    }
}