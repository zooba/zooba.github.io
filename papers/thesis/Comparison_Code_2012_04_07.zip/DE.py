import esec.landscape.real

def mutate_DE(_source, F=0.8):
    for base, p1, p2 in _source:
        new_genes = []
        for b, x1, x2 in zip(base.genome, p1.genome, p2.genome):
            new_genes.append(b + F * (x1 - x2))
        yield type(base)(new_genes, base)

SYSTEM_DEFINITION = r'''
FROM random_real(length=3,lowest=-5,highest=5) SELECT 30 population
YIELD population

BEGIN generation
  JOIN population, population, population INTO bases USING random_tuples(distinct)
  FROM bases SELECT mutants USING mutate_de

  JOIN population, mutants INTO parents
  FROM parents SELECT trials USING crossover_tuple

  JOIN population, trials INTO target_trial_pairs
  FROM target_trial_pairs SELECT population USING best_of_tuple

  YIELD population
END
'''

config = {
    'system': { 'definition': SYSTEM_DEFINITION, 'mutate_de': mutate_DE },
    'landscape': { 'class': esec.landscape.real.Sphere, 'parameters': 3 },
    'monitor': {
        'report': 'brief+local+time_delta',
        'summary': 'status+brief+best_genome',
        'limits': { 'iterations': 50 }
    },
}
