import esec.landscape.real

SYSTEM_DEFINITION = r'''
FROM random_binary(length=64) SELECT (100) population
YIELD population

BEGIN generation_equivalent
  REPEAT 100
    FROM population SELECT 2 parents, rest \
        USING binary_tournament(without_replacement)
    FROM parents SELECT offspring \
        USING crossover(per_pair_rate=0.98, two_children), \
              mutate_bitflip(per_gene_rate=1/64)
    FROM offspring, rest SELECT population
  END
  YIELD population
END
'''

config = {
    'system': { 'definition': SYSTEM_DEFINITION },
    'landscape': { 'class': esec.landscape.binary.OneMax, 'parameters': 64 },
    'monitor': {
        'report': 'brief+local+time_delta',
        'summary': 'status+brief+best_genome',
        'limits': { 'iterations': 100 }
    },
}
