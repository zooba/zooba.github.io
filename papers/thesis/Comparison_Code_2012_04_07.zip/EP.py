import esec.landscape.integer

SYSTEM_DEFINITION = r'''
FROM random_int(length=8, lowest=0, highest=25) SELECT 100 population
YIELD population

BEGIN iteration
  FROM population SELECT offspring USING mutate_delta(step_size=1, per_gene_rate=0.5)
  FROM population, offspring SELECT 100 population USING tournament(k=5)
  YIELD population
END
'''

config = {
    'system': { 'definition': SYSTEM_DEFINITION },
    'landscape': { 'class': esec.landscape.integer.Nsum, 'parameters': 8 },
    'monitor': {
        'report': 'brief+local+time_delta',
        'summary': 'status+brief+best_genome',
        'limits': { 'iterations': 50 }
    },
}
