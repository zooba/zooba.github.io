import esec.landscape.real

SYSTEM_DEFINITION = r'''
FROM random_binary(length=64) SELECT 100 population
YIELD population

BEGIN generation
  FROM population SELECT 100 parents USING fitness_proportional
  FROM parents SELECT population USING crossover(per_pair_rate=0.98), \
                                       mutate_bitflip(per_gene_rate=1/64)
  YIELD population
END
'''

config = {
    'system': { 'definition': SYSTEM_DEFINITION },
    'landscape': { 'class': esec.landscape.binary.OneMax, 'parameters': 64 },
    'monitor': {
        'report': 'brief+local+time_delta',
        'summary': 'status+brief+best_genome',
        'limits': { 'iterations': 100 }
    },
}
