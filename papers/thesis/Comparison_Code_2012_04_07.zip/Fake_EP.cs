using System;
using FakeEALib;

namespace FakeEALib.Experiments {
    class EvolutionaryProgramming {
        public static void Run() {
            var population = new Populations.Integer(8, 0, 25);
            population.Select.Add(new Selectors.Clone());
            population.Variation.Add(new Operators.MutateDelta(1, 0.5, 1.0));
            population.VariationMode = Operators.VariationMode.Expand;
            population.Sort.Add(new Sorters.Best());
            population.Filter.Add(new Filters.Truncate(100));
            population.Evaluator = new Evaluators.Integer.Nsum();
            
            population.CreateRandom(100);
            
            population.Evaluate();
            Console.WriteLine("Iter | Best Fit | Mean Fit | Worst Fit");
            Console.WriteLine("{0} | {1} | {2} | {3}", 
                0, population.Best.Fitness, population.MeanFitness, population.Worst.Fitness);
            
            for (int iteration = 1; iteration <= 50; ++iteration) {
                population.Step();
                
                population.Evaluate();
                Console.WriteLine("{0} | {1} | {2} | {3}", 
                    iteration, population.Best.Fitness, population.MeanFitness, population.Worst.Fitness);
            }
            
            Console.WriteLine("Best: {0} [{1}]", population.Best.Fitness, population.Best.ToString());
        }
    }
}