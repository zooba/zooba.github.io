package dower.ep;
import ec.*;
import ec.simple.*;
import ec.vector.*;

public class EPIndividual extends IntegerVectorIndividual
{
    public void defaultMutate(EvolutionState state, int thread)
    {
        IntegerVectorSpecies s = (IntegerVectorSpecies) species;
        if (s.mutationProbability > 0.0)
        {
            for(int x=0; x<genome.length; x++)
            {
                if (state.random[thread].nextBoolean(s.mutationProbability))
                {
                    if (state.random[thread].nextBoolean(0.5))
                        genome[x] = genome[x] + 1;
                    else
                        genome[x] = genome[x] - 1;
                    
                    if (genome[x] < (int)s.minGene(x))
                        genome[x] = (int)s.minGene(x);
                    else if (genome[x] > (int)s.maxGene(x))
                        genome[x] = (int)s.maxGene(x);
                }
            }
        }
    }
}