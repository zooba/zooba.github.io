package dower.pso;

import ec.Breeder;
import ec.EvolutionState;
import ec.Population;
import ec.pso.PSOSubpopulation;
import ec.util.Parameter;
import ec.vector.DoubleVectorIndividual;

public class PSOBreeder extends Breeder
    {
    public void setup(EvolutionState state, Parameter base) 
        {
        // intentionally empty
        }
                
    public Population breedPopulation(EvolutionState state)
        {
        PSOSubpopulation subpop = (PSOSubpopulation) state.population.subpops[0];
                
        // update bests
        assignPersonalBests(subpop);
        assignGlobalBest(subpop);

        // make a temporary copy of locations so we can modify the current location on the fly
        DoubleVectorIndividual[] tempClone = new DoubleVectorIndividual[subpop.individuals.length];
        System.arraycopy(subpop.individuals, 0, tempClone, 0, subpop.individuals.length);
                
        // update particles             
        for (int i = 0; i < subpop.individuals.length; i++)
            {
            DoubleVectorIndividual ind = (DoubleVectorIndividual)subpop.individuals[i];
            DoubleVectorIndividual prevInd = (DoubleVectorIndividual)subpop.previousIndividuals[i];
            // the individual's personal best
            DoubleVectorIndividual pBest = (DoubleVectorIndividual)subpop.personalBests[i];
            // the individuals's global best
            DoubleVectorIndividual gBest = (DoubleVectorIndividual)subpop.globalBest;
                        
            // calculate update for each dimension in the genome
            for (int j = 0; j < ind.genomeLength(); j++)
                { 
                double velocity = ind.genome[j] - prevInd.genome[j];
                double pDelta = pBest.genome[j] - ind.genome[j];                        // difference to personal best
                double gDelta = gBest.genome[j] - ind.genome[j];                        // difference to global best
                double pWeight = state.random[0].nextDouble();                          // weight for personal best
                double gWeight = state.random[0].nextDouble();                          // weight for global best
                double newDelta = (velocity + 2.0*pWeight*pDelta + 2.0*gWeight*gDelta);
                
                if (newDelta < -100.0)
                    newDelta = -100.0;
                else if (newDelta > 100.0)
                    newDelta = 100.0;
                
                ind.genome[j] += newDelta;
                }
            
            if (subpop.clampRange)
                ind.clamp();                 
            }               
                
        // update previous locations
        subpop.previousIndividuals = tempClone;
                                
        return state.population;
        }

    public void assignPersonalBests(PSOSubpopulation subpop)
        {
        for (int i = 0; i < subpop.personalBests.length; i++)                   
            if ((subpop.personalBests[i] == null) || subpop.individuals[i].fitness.betterThan(subpop.personalBests[i].fitness))
                subpop.personalBests[i] = (DoubleVectorIndividual)subpop.individuals[i].clone();
        }

    public void assignGlobalBest(PSOSubpopulation subpop)
        {
        DoubleVectorIndividual globalBest = subpop.globalBest;
        for (int i = 0; i < subpop.individuals.length; i++)
            {
            DoubleVectorIndividual ind = (DoubleVectorIndividual)subpop.individuals[i];
            if ((globalBest == null) || ind.fitness.betterThan(globalBest.fitness))
                globalBest = ind;
            }
        if (globalBest != subpop.globalBest)
            subpop.globalBest = (DoubleVectorIndividual)globalBest.clone();
        }
    }
