package dower.es;

import ec.*;
import ec.vector.*;
import ec.util.*;

public class ESIndividual extends DoubleVectorIndividual
    {
    public double[] strategy;

    public Object clone()
        {
        ESIndividual myobj = (ESIndividual) (super
            .clone());

        myobj.strategy = (double[]) (strategy.clone());

        return myobj;
        }

    public void setup(final EvolutionState state, final Parameter base)
        {
        super.setup(state, base);
        
        Parameter def = defaultBase();

        if (!(species instanceof FloatVectorSpecies))
            state.output.fatal(
                "ESIndividual requires a FloatVectorSpecies",
                base, def);
        FloatVectorSpecies s = (FloatVectorSpecies) species;

        strategy = new double[s.genomeSize];
        }

    public void defaultCrossover(EvolutionState state, int thread,
        VectorIndividual ind)
        { }

    public void defaultMutate(EvolutionState state, int thread)
    {
        FloatVectorSpecies s = (FloatVectorSpecies) species;
        boolean mutationIsBounded = s.mutationIsBounded;
        MersenneTwisterFast rng = state.random[thread];
        for (int x = 0; x < genome.length && x < strategy.length; x++)
        {
            double min = s.minGene(x);
            double max = s.maxGene(x);
            double stdev = strategy[x];

            stdev = stdev * Math.exp(rng.nextGaussian() * Math.sqrt(4.0 / genome.length) +
                                rng.nextGaussian() * (2.0 * genome.length));

            genome[x] = rng.nextGaussian() * stdev + genome[x];
        }
    }

    /**
     * Initializes the individual by randomly choosing doubles uniformly from
     * mingene to maxgene.
     */
    public void reset(EvolutionState state, int thread)
        {
        super.reset(state, thread);
        
        FloatVectorSpecies s = (FloatVectorSpecies) species;
        for (int x = 0; x < strategy.length; x++)
            strategy[x] = (state.random[thread].nextDouble() * 0.5);
        }

    public boolean equals(Object ind)
        {
        if (!super.equals(ind))
            return false;

        ESIndividual i = (ESIndividual) ind;
        if (strategy.length != i.strategy.length)
            return false;
        for (int j = 0; j < strategy.length; j++)
            if (strategy[j] != i.strategy[j])
                return false;
        return true;
        }

    }
