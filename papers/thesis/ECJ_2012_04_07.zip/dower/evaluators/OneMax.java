package dower.evaluators;
import ec.vector.*;
import ec.*;
import ec.simple.*;
import ec.util.*;

public class OneMax extends Problem implements SimpleProblemForm
    {
    public static final String P_ONEMAX = "one-max";
    
    public Parameter defaultBase()
        {
        return super.defaultBase().push(P_ONEMAX);
        }

    public void evaluate(final EvolutionState state,
        final Individual ind,
        final int subpopulation,
        final int threadnum)
        {
        if (ind.evaluated) return;

        if (!(ind instanceof BitVectorIndividual))
            state.output.fatal("Whoa!  It's not a BitVectorIndividual!!!",null);

        BitVectorIndividual ind2 = (BitVectorIndividual)ind;
        VectorSpecies s = (VectorSpecies)ind2.species;
        
        long sum=0;
        for(int x=0; x<ind2.genome.length; x++)
            {
            sum += ind2.genome[x] ? 1 : 0;
            }

        // Now we know that max is the maximum possible value, and sum is the fitness.
        
        // assume we're using SimpleFitness
        ((SimpleFitness)ind2.fitness).setFitness(state,
            /// ...the fitness...
            (float)(((double)sum)), 
            ///... our definition of the ideal individual
            sum == ind2.genome.length);
                
        ind2.evaluated = true;
        }
    }
