package dower.evaluators;
import ec.*;
import ec.simple.*;
import ec.vector.*;

public class Nsum extends Problem implements SimpleProblemForm
{
    public void evaluate(EvolutionState state, Individual ind, int subpopulation, int thread)
    {
        if (ind.evaluated) return;
        if (!(ind instanceof IntegerVectorIndividual))
            state.output.fatal("Whoa! It's not an IntegerVectorIndividual!!!");
        int[] genome = ((IntegerVectorIndividual)ind).genome;
        int sum = 0;
        for(int x=0; x < genome.length; x++)
            sum = sum + genome[x];
        ((SimpleFitness)ind.fitness).setFitness(state, sum, false);
        ind.evaluated = true;
    }
}