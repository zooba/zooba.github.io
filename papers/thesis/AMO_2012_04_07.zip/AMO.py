#   Copyright 2012 Steve Dower
# 
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.

import itertools
from esec import esdl_func
import esec.landscape.real

SYSTEM_DEFINITION = r'''
FROM random_real(length, lowest=10, highest=100) SELECT 10 instigators
FROM random_real(length, lowest=10, highest=100) SELECT 500 mob_members

YIELD mob_members

BEGIN iteration
  FROM mob_members SELECT 10 mobs USING find_mobs(count=10)

  FROM mob_members SELECT 1000 new_mob_members \
    USING move_towards(targets=mobs, speed=0.9), \
          move_towards(targets=instigators, speed=0.8), \
          repeated, \
          mutate_gaussian(sigma=1)
  FROM new_mob_members SELECT 500 mob_members USING best

  FROM instigators SELECT 500 new_instigators\
    USING move_away(targets=mobs, speed=2), \
          repeated, \
          mutate_gaussian(sigma=5)
  FROM new_instigators SELECT 10 instigators USING best

  YIELD mob_members
END
'''

@esdl_func
def move_towards(_source, targets=None, speed=1.0):
    for indiv in _source:
        new_genes = list(indiv.genome)
        for i in xrange(len(indiv.genome)):
            movement = 0
            for j in targets:
                d = j.genome[i] - new_genes[i]
                if abs(d) > 0.0001:
                    movement += 1.0 / d
            new_genes[i] += speed / len(targets) * movement
        
        yield type(indiv)(new_genes, indiv)

@esdl_func
def move_away(_source, targets=None, speed=1.0):
    for indiv in _source:
        new_genes = list(indiv.genome)
        for i in xrange(len(indiv.genome)):
            movement = 0
            for j in targets:
                d = j.genome[i] - new_genes[i]
                if abs(d) > 0.0001:
                    movement += 1.0 / d
            new_genes[i] -= speed / len(targets) * movement
        
        yield type(indiv)(new_genes, indiv)


@esdl_func
def find_mobs(_source, count=10):
    def distance(mob_member1, mob_member2):
        return sum((m1 - m2) ** 2 for m1, m2 in itertools.izip(mob_member1, mob_member2))
    
    group = list(_source)
    mob_size = int(len(group) / count)
    for _ in xrange(int(count)):
        leader = max(group, key=lambda i: i.fitness)
        group.sort(key=lambda i: distance(i, leader))
        mob = group[:mob_size]
        group = group[mob_size:]
        
        mob_location = [(sum(j[i] for j in mob) / mob_size) for i in xrange(len(leader))]
        yield type(leader)(mob_location, leader)


config = {
    'system': {
        'definition': SYSTEM_DEFINITION,
        'length': 2,
    },
    'landscape': { 'class': esec.landscape.real.Rastrigin, 'parameters': 2 },
    'monitor': {
        'report': 'brief+local+time_delta',
        'summary': 'status+brief+best_genome',
        'primary': 'mob_members',
        'limits': {
            'iterations': 100,
        }
    },
}

pathbase = 'results/AMO_00'
import os.path
i = 0
while os.path.exists(pathbase):
    i += 1
    pathbase = 'results/AMO_%02d' % i

settings = ''
settings += 'pathbase="%s";' % pathbase
settings += 'csv=True;low_priority=True;quiet=True'

def batch():
    for limit in (10, 100, 500):
        cfg = dict(config)
        cfg['random_seed'] = None
        cfg['system']['length'] = 10
        cfg['landscape']['class'] = esec.landscape.real.Sphere
        cfg['landscape']['parameters'] = 10
        cfg['monitor']['limits']['iterations'] = limit
        for _ in xrange(100):
            yield { 'config': cfg, 'tags': ['sphere10', 'iter%d' % limit] }

        cfg = dict(config)
        cfg['random_seed'] = None
        cfg['system']['length'] = 2
        cfg['landscape']['class'] = esec.landscape.real.Rastrigin
        cfg['landscape']['parameters'] = 2
        cfg['monitor']['limits']['iterations'] = limit
        for _ in xrange(100):
            yield { 'config': cfg, 'tags': ['rastrigin2', 'iter%d' % limit] }

        cfg = dict(config)
        cfg['random_seed'] = None
        cfg['system']['length'] = 10
        cfg['landscape']['class'] = esec.landscape.real.Rastrigin
        cfg['landscape']['parameters'] = 10
        cfg['monitor']['limits']['iterations'] = limit
        for _ in xrange(100):
            yield { 'config': cfg, 'tags': ['rastrigin10', 'iter%d' % limit] }
