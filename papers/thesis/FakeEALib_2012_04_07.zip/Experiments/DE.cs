using System;
using System.Collections.Generic;
using FakeEALib;

namespace FakeEALib.Experiments {
    class DifferentialEvolution {
        public static void Run() {
            var population = new Populations.Real(3, -5.0, 5.0);

            population.Select.Add(new Selectors.Clone());
            population.Variation.Add(new MutateDE(0.8));
            population.VariationMode = Operators.VariationMode.Tournament;
            population.Evaluator = new Evaluators.Real.Sphere();

            population.CreateRandom(30);

            population.Evaluate();
            Console.WriteLine("Iter | Best Fit | Mean Fit | Worst Fit");
            Console.WriteLine("{0} | {1} | {2} | {3}", 
                0, population.Best.Fitness, population.MeanFitness, population.Worst.Fitness);

            for (int iteration = 1; iteration <= 50; ++iteration) {
                population.Step();

                population.Evaluate();
                Console.WriteLine("{0} | {1} | {2} | {3}", 
                    iteration, population.Best.Fitness, population.MeanFitness, population.Worst.Fitness);
            }

             Console.WriteLine("Best: {0} [{1}]", population.Best.Fitness, population.Best.ToString());
       }
    }

    class MutateDE : Operators.IOperator {
        public double F { get; private set; }

        public MutateDE(double F) {
            this.F = F;
        }

        public void Vary(IList<Populations.IIndividual> source, int index) {
            int j = Random.Integer(source.Count);
            while (j == index) {
                j = Random.Integer(source.Count);
            }

            int k = Random.Integer(source.Count);
            while (k == index || k == j) {
                k = Random.Integer(source.Count);
            }

            var result = (Populations.IRealIndividual)source[index];
            var p1 = (Populations.IRealIndividual)source[j];
            var p2 = (Populations.IRealIndividual)source[k];

            for (int i = 0; i < result.Count; ++i) {
                if (Random.Probability(0.5)) {
                    result[i] += F * (p1[i] - p2[i]);
                }
            }
        }
    }
}