using System;
using FakeEALib;

namespace FakeEALib.Experiments {
    class GeneticAlgorithm {
        public static void Run() {
            var population = new Populations.Binary(64);
            population.Select.Add(new Selectors.FitnessProportional(true, 100));
            population.Select.Add(new Selectors.Clone());
            population.Evaluator = new Evaluators.Binary.OneMax();
            population.Variation.Add(new Operators.Crossover(1, 0.98));
            population.Variation.Add(new Operators.MutateBitflip(1.0, 1.0 / 64));
            population.VariationMode = Operators.VariationMode.Replace;

            population.CreateRandom(100);

            population.Evaluate();
            Console.WriteLine("Iter | Best Fit | Mean Fit | Worst Fit");
            Console.WriteLine("{0} | {1} | {2} | {3}", 
                0, population.Best.Fitness, population.MeanFitness, population.Worst.Fitness);

            for (int iteration = 1; iteration <= 100; ++iteration) {
                population.Step();

                population.Evaluate();
                Console.WriteLine("{0} | {1} | {2} | {3}", 
                    iteration, population.Best.Fitness, population.MeanFitness, population.Worst.Fitness);
            }

            Console.WriteLine("Best: {0} [{1}]", population.Best.Fitness, population.Best.ToString());
        }
    }
}