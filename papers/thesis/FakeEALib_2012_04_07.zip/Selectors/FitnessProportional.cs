﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FakeEALib.Selectors {
    class FitnessProportional : ISelector {
        public readonly bool Replacement;
        public readonly int Count;

        public FitnessProportional(bool replacement, int count) {
            Replacement = replacement;
            Count = count;
        }


        public List<Populations.IIndividual> Select(IList<Populations.IIndividual> source) {
            var indivs = source.ToList();
            indivs.Sort();
            var result = new List<Populations.IIndividual>();

            var offset = indivs.Last().Fitness;
            var totalFitness = indivs.Sum(i => i.Fitness - offset);

            while (result.Count < Count) {
                var p = Random.Uniform(0.0, totalFitness);

                Populations.IIndividual winner = indivs.First();
                foreach (var indiv in indivs) {
                    p -= indiv.Fitness - offset;
                    if (p <= 0) {
                        winner = indiv;
                        break;
                    }
                }

                result.Add(winner);
                if (!Replacement) {
                    indivs.Remove(winner);
                    totalFitness -= winner.Fitness - offset;
                }
            }

            return result;
        }
    }
}
