﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FakeEALib.Selectors {
    class Clone : ISelector {
        public List<Populations.IIndividual> Select(IList<Populations.IIndividual> source) {
            return source.AsEnumerable().Select(p => p.Clone()).ToList();
        }
    }
}
