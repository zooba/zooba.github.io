﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FullAlgorithms {
    static class DifferentialEvolution {
        private class Individual : IComparable<Individual> {
            public readonly double[] Genome;
            public double Fitness;

            public Individual(int length) {
                Genome = new double[length];
            }

            public int CompareTo(Individual other) {
                return other.Fitness.CompareTo(Fitness);
            }

            public override string ToString() {
                return String.Join(", ", Genome);
            }
        }

        private static void PrintSummary(int iteration, List<Individual> indivs) {
            indivs.Sort();
            double total = 0;
            foreach (var indiv in indivs) {
                total += indiv.Fitness;
            }
            double average = total / indivs.Count;

            Console.WriteLine("{0} | {1} | {2} | {3}",
                iteration, indivs[0].Fitness, average, indivs[indivs.Count - 1].Fitness);
        }

        public static void Run() {
            var rnd = new Random();
            var population = new List<Individual>();

            for (int i = 0; i < 30; ++i) {
                var indiv = new Individual(3);
                for (int j = 0; j < indiv.Genome.Length; ++j) {
                    indiv.Genome[j] = rnd.NextDouble() * 10.0 - 5.0;
                }
                population.Add(indiv);
            }

            foreach (var indiv in population) {
                double total = 0;
                for (int j = 0; j < indiv.Genome.Length; ++j) {
                    total += indiv.Genome[j] * indiv.Genome[j];
                }
                indiv.Fitness = -total;
            }

            Console.WriteLine("Iter | Best Fit | Mean Fit | Worst Fit");
            PrintSummary(0, population);

            for (int iteration = 1; iteration <= 50; ++iteration) {
                for (int i = 0; i < population.Count; ++i) {
                    int i1 = rnd.Next(population.Count);
                    while (i1 == i) {
                        i1 = rnd.Next(population.Count);
                    }

                    int i2 = rnd.Next(population.Count);
                    while (i2 == i || i2 == i1) {
                        i2 = rnd.Next(population.Count);
                    }

                    var child = new Individual(population[i].Genome.Length);
                    var p1 = population[i1].Genome;
                    var p2 = population[i2].Genome;

                    for (int j = 0; j < child.Genome.Length; ++j) {
                        if (rnd.NextDouble() < 0.5) {
                            child.Genome[j] = population[i].Genome[j] + 0.8 * (p1[j] - p2[j]);
                        } else {
                            child.Genome[j] = population[i].Genome[j];
                        }
                    }

                    double total = 0;
                    for (int j = 0; j < child.Genome.Length; ++j) {
                        total += child.Genome[j] * child.Genome[j];
                    }
                    child.Fitness = -total;

                    if (child.Fitness > population[i].Fitness) {
                        population[i] = child;
                    }
                }

                PrintSummary(iteration, population);
            }

            Console.WriteLine("Best: {0} [{1}]", population[0].Fitness, population[0].ToString());
        }
    }
}
