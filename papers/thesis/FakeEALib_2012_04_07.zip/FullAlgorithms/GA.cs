﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FullAlgorithms {
    static class GeneticAlgorithm {
        private class Individual : IComparable<Individual> {
            public readonly bool[] Genome;
            public double Fitness;

            public Individual(int length) {
                Genome = new bool[length];
            }

            public int CompareTo(Individual other) {
                return other.Fitness.CompareTo(Fitness);
            }

            public override string ToString() {
                return String.Join(", ", Genome);
            }
        }

        private static void PrintSummary(int iteration, List<Individual> indivs) {
            indivs.Sort();
            double total = 0;
            foreach (var indiv in indivs) {
                total += indiv.Fitness;
            }
            double average = total / indivs.Count;

            Console.WriteLine("{0} | {1} | {2} | {3}",
                iteration, indivs[0].Fitness, average, indivs[indivs.Count - 1].Fitness);
        }

        public static void Run() {
            var rnd = new Random();
            var population = new List<Individual>();

            for (int i = 0; i < 100; ++i) {
                var indiv = new Individual(64);
                for (int j = 0; j < indiv.Genome.Length; ++j) {
                    indiv.Genome[j] = rnd.NextDouble() < 0.5;
                }
                population.Add(indiv);
            }

            foreach (var indiv in population) {
                double total = 0;
                for (int j = 0; j < indiv.Genome.Length; ++j) {
                    total += indiv.Genome[j] ? 1.0 : 0.0;
                }
                indiv.Fitness = total;
            }

            Console.WriteLine("Iter | Best Fit | Mean Fit | Worst Fit");
            PrintSummary(0, population);

            for (int iteration = 1; iteration <= 100; ++iteration) {
                double fitnessTotal = 0;
                foreach (var indiv in population) {
                    fitnessTotal += indiv.Fitness;
                }

                var parents = new List<Individual>();

                while (parents.Count < population.Count) {
                    var prob = rnd.NextDouble() * fitnessTotal;

                    foreach (var indiv in population) {
                        prob -= indiv.Fitness;
                        if (prob <= 0) {
                            parents.Add(indiv);
                            break;
                        }
                    }
                }

                population.Clear();
                for (int i = 0; i < parents.Count; i += 2) {
                    var p1 = parents[i];
                    var p2 = parents[i + 1];

                    int cut = rnd.Next(1, p1.Genome.Length - 1);
                    var c1 = new Individual(p1.Genome.Length);
                    var c2 = new Individual(p1.Genome.Length);

                    for (int j = 0; j < p1.Genome.Length; ++j) {
                        if (j < cut) {
                            c1.Genome[j] = p1.Genome[j];
                            c2.Genome[j] = p2.Genome[j];
                        } else {
                            c2.Genome[j] = p1.Genome[j];
                            c1.Genome[j] = p2.Genome[j];
                        }

                        if (rnd.NextDouble() < (1.0 / 64.0)) {
                            c1.Genome[j] = !c1.Genome[j];
                        }
                        if (rnd.NextDouble() < (1.0 / 64.0)) {
                            c2.Genome[j] = !c2.Genome[j];
                        }
                    }

                    population.Add(c1);
                    population.Add(c2);
                }

                foreach (var indiv in population) {
                    double total = 0;
                    for (int j = 0; j < indiv.Genome.Length; ++j) {
                        total += indiv.Genome[j] ? 1.0 : 0.0;
                    }
                    indiv.Fitness = total;
                }

                PrintSummary(iteration, population);
            }

            Console.WriteLine("Best: {0} [{1}]", population[0].Fitness, population[0].ToString());
        }
    }
}
