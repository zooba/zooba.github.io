﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FullAlgorithms {
    static class EvolutionStrategy {
        private class Individual : IComparable<Individual> {
            public readonly double[] Genome;
            public readonly double[] Strategy;
            public double Fitness;

            public Individual(int length) {
                Genome = new double[length];
                Strategy = new double[length];
            }

            public int CompareTo(Individual other) {
                return other.Fitness.CompareTo(Fitness);
            }

            public override string ToString() {
                return String.Join(", ", Genome);
            }
        }

        private static double? _NextGauss = null;
        private static double Normal(this Random rnd) {
            if (_NextGauss.HasValue) {
                var value = _NextGauss.Value;
                _NextGauss = null;
                return value;
            } else {
                double x2pi = rnd.NextDouble() * Math.PI * 2;
                double g2rad = Math.Sqrt(-2.0 * Math.Log(1.0 - rnd.NextDouble()));
                _NextGauss = Math.Sin(x2pi) * g2rad;
                return Math.Cos(x2pi) * g2rad;
            }
        }

        private static void PrintSummary(int iteration, List<Individual> indivs) {
            indivs.Sort();
            double total = 0;
            foreach (var indiv in indivs) {
                total += indiv.Fitness;
            }
            double average = total / indivs.Count;

            Console.WriteLine("{0} | {1} | {2} | {3}",
                iteration, indivs[0].Fitness, average, indivs[indivs.Count - 1].Fitness);
        }

        public static void Run() {
            var rnd = new Random();
            var population = new List<Individual>();

            for (int i = 0; i < 20; ++i) {
                var indiv = new Individual(10);
                for (int j = 0; j < indiv.Genome.Length; ++j) {
                    indiv.Genome[j] = rnd.NextDouble() * 10 - 5;
                    indiv.Strategy[j] = rnd.NextDouble() * 0.5;
                }
                population.Add(indiv);
            }

            foreach (var indiv in population) {
                double total = 0;
                for (int j = 0; j < indiv.Genome.Length; ++j) {
                    total += indiv.Genome[j] * indiv.Genome[j];
                }
                indiv.Fitness = -total;
            }

            Console.WriteLine("Iter | Best Fit | Mean Fit | Worst Fit");
            PrintSummary(0, population);

            for (int iteration = 1; iteration <= 50; ++iteration) {
                var offspring = new List<Individual>();
                for (int i = 0; i < 2; ++i) {
                    foreach (var indiv in population) {
                        var child = new Individual(10);
                        for (int j = 0; j < indiv.Genome.Length; ++j) {
                            child.Strategy[j] = indiv.Strategy[j] * Math.Exp(
                                rnd.Normal() * Math.Sqrt(4.0 / indiv.Genome.Length) +
                                rnd.Normal() / (2.0 * indiv.Genome.Length));

                            child.Genome[j] = indiv.Genome[j] + child.Strategy[j] * rnd.Normal();
                        }
                        offspring.Add(child);
                    }
                }

                foreach (var indiv in offspring) {
                    double total = 0;
                    for (int j = 0; j < indiv.Genome.Length; ++j) {
                        total += indiv.Genome[j] * indiv.Genome[j];
                    }
                    indiv.Fitness = -total;
                }

                population.AddRange(offspring);

                population.Sort();

                population.RemoveRange(20, population.Count - 20);

                PrintSummary(iteration, population);
            }

            Console.WriteLine("Best: {0} [{1}]", population[0].Fitness, population[0].ToString());
        }
    }
}
