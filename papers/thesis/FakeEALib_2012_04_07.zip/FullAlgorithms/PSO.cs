﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FullAlgorithms {
    static class ParticleSwarmOptimisation {
        private class Individual : IComparable<Individual> {
            public readonly double[] Genome;
            public readonly double[] Velocity;
            public double Fitness;

            public Individual(int length) {
                Genome = new double[length];
                Velocity = new double[length];
            }

            public int CompareTo(Individual other) {
                return other.Fitness.CompareTo(Fitness);
            }

            public override string ToString() {
                return String.Join(", ", Genome);
            }

            public Individual Clone() {
                var indiv = new Individual(Genome.Length);
                Genome.CopyTo(indiv.Genome, 0);
                Velocity.CopyTo(indiv.Velocity, 0);
                indiv.Fitness = Fitness;
                return indiv;
            }
        }

        private static void PrintSummary(int iteration, List<Individual> indivs) {
            indivs.Sort();
            double total = 0;
            foreach (var indiv in indivs) {
                total += indiv.Fitness;
            }
            double average = total / indivs.Count;

            Console.WriteLine("{0} | {1} | {2} | {3}",
                iteration, indivs[0].Fitness, average, indivs[indivs.Count - 1].Fitness);
        }

        public static void Run() {
            var rnd = new Random();
            var swarm = new List<Individual>();
            var p_bests = new List<Individual>();

            for (int i = 0; i < 50; ++i) {
                var indiv = new Individual(2);
                for (int j = 0; j < indiv.Genome.Length; ++j) {
                    indiv.Genome[j] = rnd.NextDouble() * 10.0 - 5.0;
                    indiv.Velocity[j] = 0.0;
                }
                swarm.Add(indiv);
                p_bests.Add(indiv);
            }

            foreach (var indiv in swarm) {
                double total = 0;
                for (int j = 0; j < indiv.Genome.Length; ++j) {
                    total += indiv.Genome[j] * indiv.Genome[j];
                }
                indiv.Fitness = -total;
            }

            Console.WriteLine("Iter | Best Fit | Mean Fit | Worst Fit");
            PrintSummary(0, swarm);

            for (int iteration = 1; iteration <= 50; ++iteration) {
                var g_best = swarm[0].Clone();

                for (int i = 0; i < swarm.Count; ++i) {
                    var pos = swarm[i].Genome;
                    var vel = swarm[i].Velocity;
                    var p_i = p_bests[i].Genome;
                    var p_g = g_best.Genome;
                    for (int j = 0; j < pos.Length; ++j) {
                        double newV = vel[j] + 2.0 * rnd.NextDouble() * (p_i[j] - pos[j]) +
                            2.0 * rnd.NextDouble() * (p_g[j] - pos[j]);

                        if (newV < -100) {
                            newV = -100;
                        } else if (newV > 100) {
                            newV = 100;
                        }

                        pos[j] += newV;

                        if (pos[j] < -5) {
                            pos[j] = -10 - pos[j];
                            newV = -newV;
                        } else if (pos[j] > 5) {
                            pos[j] = 10 - pos[j];
                            newV = -newV;
                        }

                        vel[j] = newV;
                    }
                }

                for (int i = 0; i < swarm.Count; ++i) {
                    var indiv = swarm[i];
                    double total = 0;
                    for (int j = 0; j < indiv.Genome.Length; ++j) {
                        total += indiv.Genome[j] * indiv.Genome[j];
                    }
                    indiv.Fitness = -total;

                    if (indiv.Fitness > p_bests[i].Fitness) {
                        p_bests[i] = indiv.Clone();
                    }
                }

                PrintSummary(iteration, swarm);
            }

            Console.WriteLine("Best: {0} [{1}]", swarm[0].Fitness, swarm[0].ToString());
        }
    }
}
