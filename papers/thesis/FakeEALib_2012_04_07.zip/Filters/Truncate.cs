﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FakeEALib.Filters {
    class Truncate : IFilter {
        public readonly int Count;

        public Truncate(int count) {
            Count = count;
        }

        public void Filter(Populations.IPopulation source) {
            while (source.Count > Count) {
                source.RemoveAt(source.Count - 1);
            }
        }
    }
}
