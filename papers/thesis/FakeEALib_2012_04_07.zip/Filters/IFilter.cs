﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FakeEALib.Filters {
    interface IFilter {
        void Filter(Populations.IPopulation source);
    }
}
