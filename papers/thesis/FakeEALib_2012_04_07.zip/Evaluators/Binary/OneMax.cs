﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FakeEALib.Evaluators.Binary {
    class OneMax : IEvaluator {
        public double Evaluate(IList<Populations.IIndividual> source, int index) {
            var indiv = ((Populations.IBinaryIndividual)source[index]);

            return indiv.Sum(x => x ? 1.0 : 0.0);
        }
    }
}
