﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FakeEALib.Evaluators.Integer {
    class Nsum : IEvaluator {
        public double Evaluate(IList<Populations.IIndividual> source, int index) {
            var indiv = ((Populations.IIntegerIndividual)source[index]);

            return (double)indiv.Sum();
        }
    }
}
