﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FakeEALib.Evaluators.Real {
    class Sphere : IEvaluator {
        public double Evaluate(IList<Populations.IIndividual> source, int index) {
            var indiv = (Populations.IRealIndividual)source[index];

            return -indiv.Sum(x => x * x);
        }
    }
}
