﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FakeEALib {
    class Program {
        static void Main(string[] args) {
            Console.WriteLine();
            Console.WriteLine("EP - Full C# implementation");
            FullAlgorithms.EvolutionaryProgramming.Run();
            if (Console.ReadKey().Key == ConsoleKey.Escape) return;
            Console.WriteLine();
            Console.WriteLine("EP - FakeEALib implementation");
            Experiments.EvolutionaryProgramming.Run();
            if (Console.ReadKey().Key == ConsoleKey.Escape) return;

            Console.WriteLine();
            Console.WriteLine("ES - Full C# implementation");
            FullAlgorithms.EvolutionStrategy.Run();
            if (Console.ReadKey().Key == ConsoleKey.Escape) return;
            Console.WriteLine();
            Console.WriteLine("ES - FakeEALib implementation");
            Experiments.EvolutionStrategy.Run();
            if (Console.ReadKey().Key == ConsoleKey.Escape) return;

            Console.WriteLine();
            Console.WriteLine("GA - Full C# implementation");
            FullAlgorithms.GeneticAlgorithm.Run();
            if (Console.ReadKey().Key == ConsoleKey.Escape) return;
            Console.WriteLine();
            Console.WriteLine("GA - FakeEALib implementation");
            Experiments.GeneticAlgorithm.Run();
            if (Console.ReadKey().Key == ConsoleKey.Escape) return;

            Console.WriteLine();
            Console.WriteLine("DE - Full C# implementation");
            FullAlgorithms.DifferentialEvolution.Run();
            if (Console.ReadKey().Key == ConsoleKey.Escape) return;
            Console.WriteLine();
            Console.WriteLine("DE - FakeEALib implementation");
            Experiments.DifferentialEvolution.Run();
            if (Console.ReadKey().Key == ConsoleKey.Escape) return;

            Console.WriteLine();
            Console.WriteLine("PSO - Full C# implementation");
            FullAlgorithms.ParticleSwarmOptimisation.Run();
            if (Console.ReadKey().Key == ConsoleKey.Escape) return;
            Console.WriteLine();
            Console.WriteLine("PSO - FakeEALib implementation");
            Experiments.ParticleSwarmOptimisation.Run();
            if (Console.ReadKey().Key == ConsoleKey.Escape) return;

            Console.WriteLine();
            Console.WriteLine("SSGA - Full C# implementation");
            FullAlgorithms.SteadyStateGeneticAlgorithm.Run();
            if (Console.ReadKey().Key == ConsoleKey.Escape) return;
            Console.WriteLine();
            Console.WriteLine("SSGA - FakeEALib implementation");
            Experiments.SteadyStateGeneticAlgorithms.Run();
            if (Console.ReadKey().Key == ConsoleKey.Escape) return;
        }
    }
}
