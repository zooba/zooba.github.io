﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FakeEALib.Operators {
    class Crossover : IOperator {
        public readonly int Points;
        public readonly double PerPairRate;

        public Crossover(int points, double perPairRate) {
            Points = points;
            PerPairRate = perPairRate;
        }

        public void Vary(IList<Populations.IIndividual> source, int index) {
            if ((index % 2) == 1 || index + 1 == source.Count || !Random.Probability(PerPairRate)) {
                return;
            }

            var indiv1 = (System.Collections.IList)source[index];
            var indiv2 = (System.Collections.IList)source[index + 1];

            var cutPoints = new HashSet<int>();
            while (cutPoints.Count < Points) {
                cutPoints.Add(Random.Integer(1, Math.Min(indiv1.Count, indiv2.Count) - 1));
            }

            bool exchanging = false;
            for (int j = 0; j < indiv1.Count && j < indiv2.Count; ++j) {
                if (exchanging) {
                    var temp = indiv1[j];
                    indiv1[j] = indiv2[j];
                    indiv2[j] = temp;
                }

                if (cutPoints.Contains(j)) {
                    exchanging = !exchanging;
                }
            }
        }
    }
}
