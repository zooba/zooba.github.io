﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FakeEALib.Operators {
    class MutateDelta : IOperator {
        public readonly double StepSize;
        public readonly double PerGeneRate;
        public readonly double PerIndivRate;
        
        public MutateDelta(double stepSize, double perGeneRate, double perIndivRate) {
            StepSize = stepSize;
            PerGeneRate = perGeneRate;
            PerIndivRate = perIndivRate;
        }

        public void Vary(IList<Populations.IIndividual> source, int index) {
            Populations.IIntegerIndividual iIndiv;
            Populations.IRealIndividual rIndiv;

            if (!Random.Probability(PerIndivRate)) {
                return;
            }

            if ((iIndiv = source[index] as Populations.IIntegerIndividual) != null) {
                // Integer
                for (int j = 0; j < iIndiv.Count; ++j) {
                    if (Random.Probability(PerGeneRate)) {
                        if (Random.Probability(0.5)) {
                            iIndiv[j] += (int)StepSize;
                        } else {
                            iIndiv[j] -= (int)StepSize;
                        }
                    }
                }
            } else if ((rIndiv = source[index] as Populations.IRealIndividual) != null) {
                // Real
                for (int j = 0; j < rIndiv.Count; ++j) {
                    if (Random.Probability(PerGeneRate)) {
                        if (Random.Probability(0.5)) {
                            rIndiv[j] += StepSize;
                        } else {
                            rIndiv[j] -= StepSize;
                        }
                    }
                }
            } else {
                throw new ArgumentException("Cannot mutate " + source[index].GetType().ToString());
            }
        }
    }
}
