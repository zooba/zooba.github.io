﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FakeEALib.Operators {
    class MutateBitflip : IOperator {
        public readonly double PerIndivRate;
        public readonly double PerGeneRate;

        public MutateBitflip(double perIndivRate, double perGeneRate) {
            PerIndivRate = perIndivRate;
            PerGeneRate = perGeneRate;
        }

        public void Vary(IList<Populations.IIndividual> source, int index) {
            if (!Random.Probability(PerIndivRate)) {
                return;
            }

            var indiv = (Populations.IBinaryIndividual)source[index];
            for (int j = 0; j < indiv.Count; ++j) {
                if (Random.Probability(PerGeneRate)) {
                    indiv[j] = !indiv[j];
                }
            }
        }
    }
}
