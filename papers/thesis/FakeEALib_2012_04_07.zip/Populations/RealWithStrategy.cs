﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FakeEALib.Populations {
    class RealIndividualWithStrategy : List<double>, IRealIndividualWithStrategy {
        public RealIndividualWithStrategy() {
            Strategy = new List<double>();
        }

        public IIndividual Clone() {
            var inst = new RealIndividualWithStrategy();
            ((List<double>)inst).AddRange(this);
            ((List<double>)inst.Strategy).AddRange(Strategy);
            inst.Fitness = Fitness;
            return inst;
        }

        public IList<double> Strategy { get; private set; }
        public double Fitness { get; set; }

        public int CompareTo(IIndividual other) {
            return -Fitness.CompareTo(other.Fitness);
        }

        public bool Equals(IIndividual other) {
            var rOther = other as IRealIndividualWithStrategy;
            return rOther != null && this.SequenceEqual(rOther);
        }

        public override string ToString() {
            return String.Join(", ", this.Select(i => i.ToString()));
        }
    }

    class RealWithStrategy : PopulationBase {
        public int Length { get; private set; }
        public double Lowest { get; private set; }
        public double Highest { get; private set; }
        public double StrategyLowest { get; private set; }
        public double StrategyHighest { get; private set; }

        public RealWithStrategy(int length, double lowest, double highest,
            double strategyLowest, double strategyHighest) {
            Length = length;
            Lowest = lowest;
            Highest = highest;
            StrategyLowest = strategyLowest;
            StrategyHighest = strategyHighest;
        }

        public override void CreateRandom(int count) {
            for (int i = 0; i < count; ++i) {
                var indiv = new RealIndividualWithStrategy();
                for (int j = 0; j < Length; ++j) {
                    indiv.Add(Random.Uniform(Lowest, Highest));
                    indiv.Strategy.Add(Random.Uniform(StrategyLowest, StrategyHighest));
                }
                Add(indiv);
            }
        }
    }
}
