﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FakeEALib.Populations {
    abstract class PopulationBase : List<IIndividual>, IPopulation {
        protected List<Selectors.ISelector> _Select = null;
        public IList<Selectors.ISelector> Select {
            get {
                if (_Select == null) {
                    _Select = new List<Selectors.ISelector>();
                }
                return _Select;
            }
        }

        protected List<Operators.IOperator> _Variation = null;
        public IList<Operators.IOperator> Variation {
            get {
                if (_Variation == null) {
                    _Variation = new List<Operators.IOperator>();
                }
                return _Variation;
            }
        }

        public Operators.VariationMode VariationMode { get; set; }

        protected List<Sorters.ISorter> _Sort = null;
        public new IList<Sorters.ISorter> Sort {
            get {
                if (_Sort == null) {
                    _Sort = new List<Sorters.ISorter>();
                }
                return _Sort;
            }
        }

        protected List<Filters.IFilter> _Filter = null;
        public IList<Filters.IFilter> Filter {
            get {
                if (_Filter == null) {
                    _Filter = new List<Filters.IFilter>();
                }
                return _Filter;
            }
        }

        public Evaluators.IEvaluator Evaluator { get; set; }

        public void Evaluate() {
            if (Evaluator != null) {
                for (int i = 0; i < Count; ++i) {
                    this[i].Fitness = Evaluator.Evaluate(this, i);
                }
            }
        }

        public abstract void CreateRandom(int count);

        public void Step() {
            Vary();
            SortFilter();
        }

        public void Vary() {
            List<IIndividual> indivs;
            if (_Select != null) {
                indivs = this;
                foreach (var selector in _Select) {
                    indivs = selector.Select(indivs);
                }
            } else {
                indivs = this;
            }

            if (_Variation != null) {
                foreach (var variation in _Variation) {
                    for (int i = 0; i < indivs.Count; ++i) {
                        variation.Vary(indivs, i);
                    }
                }
            } else if (indivs == this) {
                return;
            }

            if (VariationMode == Operators.VariationMode.Expand) {
                this.AddRange(indivs);
            } else if (VariationMode == Operators.VariationMode.Tournament) {
                for (int i = 0; i < indivs.Count; ++i) {
                    indivs[i].Fitness = Evaluator.Evaluate(indivs, i);

                    if (indivs[i].CompareTo(this[i]) < 0) {
                        this[i] = indivs[i];
                    }
                }
            } else if (VariationMode == Operators.VariationMode.Replace) {
                if (indivs != this) {
                    this.Clear();
                    this.AddRange(indivs);
                }
            }
        }

        public void SortFilter() {
            if (_Sort != null) {
                foreach (var sorter in _Sort) {
                    sorter.Sort(this);
                }
            }

            if (_Filter != null) {
                foreach (var filter in _Filter) {
                    filter.Filter(this);
                }
            }
        }

        public virtual IEnumerable<IIndividual> Unfiltered {
            get { return this; }
        }

        public IIndividual Best {
            get { return this.Min(); }
        }

        public IIndividual Worst {
            get { return this.Max(); }
        }

        public double MeanFitness {
            get {
                return this.Sum(i => i.Fitness) / this.Count;
            }
        }

        public void AddClonedRange(IEnumerable<IIndividual> source) {
            AddRange(source.Select(i => i.Clone()));
        }

        public IList<IIndividual> AsNextStep() {
            var temp = (PopulationBase)this.MemberwiseClone();

            temp.Clear();
            temp.AddClonedRange(this);
            temp.Step();

            return temp;
        }
    }
}
