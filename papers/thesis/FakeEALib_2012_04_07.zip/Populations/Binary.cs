﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FakeEALib.Populations {
    class BinaryIndividual : List<bool>, IBinaryIndividual {
        public IIndividual Clone() {
            var inst = new BinaryIndividual();
            ((List<bool>)inst).AddRange(this);
            inst.Fitness = Fitness;
            return inst;
        }
        
        public double Fitness { get; set; }

        public int CompareTo(IIndividual other) {
            return -Fitness.CompareTo(other.Fitness);
        }

        public bool Equals(IIndividual other) {
            var bOther = other as IBinaryIndividual;
            return bOther != null && this.SequenceEqual(bOther);
        }

        public override string ToString() {
            return String.Join(", ", this.Select(i => i.ToString()));
        }
    }
    
    class Binary : PopulationBase {
        public int Length { get; private set; }

        public Binary(int length) {
            Length = length;
        }

        public override void CreateRandom(int count) {
            for (int i = 0; i < count; ++i) {
                var indiv = new BinaryIndividual();
                for (int j = 0; j < Length; ++j) {
                    indiv.Add(Random.Probability(0.5));
                }
                Add(indiv);
            }
        }
    }
}
