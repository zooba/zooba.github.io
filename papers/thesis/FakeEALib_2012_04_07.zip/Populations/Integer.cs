﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FakeEALib.Populations {
    class IntegerIndividual : List<int>, IIntegerIndividual {
        public IIndividual Clone() {
            var inst = new IntegerIndividual();
            ((List<int>)inst).AddRange(this);
            inst.Fitness = Fitness;
            return inst;
        }
        
        public double Fitness { get; set; }

        public int CompareTo(IIndividual other) {
            return -Fitness.CompareTo(other.Fitness);
        }

        public bool Equals(IIndividual other) {
            var iOther = other as IIntegerIndividual;
            return iOther != null && this.SequenceEqual(iOther);
        }

        public override string ToString() {
            return String.Join(", ", this.Select(i => i.ToString()));
        }
    }
    
    class Integer : PopulationBase {
        public int Length { get; private set; }
        public int Lowest { get; private set; }
        public int Highest { get; private set; }

        public Integer(int length, int lowest, int highest) {
            Length = length;
            Lowest = lowest;
            Highest = highest;
        }

        public override void CreateRandom(int count) {
            for (int i = 0; i < count; ++i) {
                var indiv = new IntegerIndividual();
                for (int j = 0; j < Length; ++j) {
                    indiv.Add(Random.Integer(Lowest, Highest));
                }
                Add(indiv);
            }
        }
    }
}
