﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FakeEALib.Populations {
    interface IPopulation : IList<IIndividual>, IEnumerable<IIndividual> {
        IList<Selectors.ISelector> Select { get; }
        IList<Operators.IOperator> Variation { get; }
        Operators.VariationMode VariationMode { get; set; }
        IList<Sorters.ISorter> Sort { get; }
        IList<Filters.IFilter> Filter { get; }
        
        Evaluators.IEvaluator Evaluator { get; set; }
        void Evaluate();

        void CreateRandom(int count);

        void Step();
        void Vary();
        void SortFilter();

        IEnumerable<IIndividual> Unfiltered { get; }

        IIndividual Best { get; }
        IIndividual Worst { get; }
        double MeanFitness { get; }

        void AddClonedRange(IEnumerable<IIndividual> source);
    }
}
