﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FakeEALib.Populations {
    interface IIndividual : IComparable<IIndividual>, IEquatable<IIndividual> {
        double Fitness { get; set; }
        IIndividual Clone();
    }

    interface IBinaryIndividual : IIndividual, IList<bool> { }

    interface IIntegerIndividual : IIndividual, IList<int> { }

    interface IRealIndividual : IIndividual, IList<double> { }

    interface IRealIndividualWithStrategy : IRealIndividual {
        IList<double> Strategy { get; }
    }
}
