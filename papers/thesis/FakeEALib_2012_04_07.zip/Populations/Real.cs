﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FakeEALib.Populations {
    class RealIndividual : List<double>, IRealIndividual {
        public IIndividual Clone() {
            var inst = new RealIndividual();
            ((List<double>)inst).AddRange(this);
            inst.Fitness = Fitness;
            return inst;
        }

        public double Fitness { get; set; }

        public int CompareTo(IIndividual other) {
            return -Fitness.CompareTo(other.Fitness);
        }

        public bool Equals(IIndividual other) {
            var rOther = other as IRealIndividual;
            return rOther != null && this.SequenceEqual(rOther);
        }

        public override string ToString() {
            return String.Join(", ", this.Select(i => i.ToString()));
        }
    }

    class Real : PopulationBase {
        public int Length { get; private set; }
        public double Lowest { get; private set; }
        public double Highest { get; private set; }

        public Real(int length, double lowest, double highest) {
            Length = length;
            Lowest = lowest;
            Highest = highest;
        }

        public override void CreateRandom(int count) {
            for (int i = 0; i < count; ++i) {
                var indiv = new RealIndividualWithStrategy();
                for (int j = 0; j < Length; ++j) {
                    indiv.Add(Random.Uniform(Lowest, Highest));
                }
                Add(indiv);
            }
        }
    }
}
