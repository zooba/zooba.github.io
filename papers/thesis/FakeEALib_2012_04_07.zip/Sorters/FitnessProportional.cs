﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FakeEALib.Sorters {
    class FitnessProportional : ISorter {
        public void Sort(Populations.IPopulation source) {
            var indivs = source.ToList();
            indivs.Sort();

            source.Clear();
            var offset = indivs.Last().Fitness;
            var totalFitness = indivs.Sum(i => i.Fitness - offset);

            while (indivs.Any()) {
                var p = Random.Uniform(0.0, totalFitness);

                Populations.IIndividual winner = indivs.First();
                foreach (var indiv in indivs) {
                    p -= indiv.Fitness - offset;
                    if (p <= 0) {
                        winner = indiv;
                        break;
                    }
                }

                source.Add(winner);
                indivs.Remove(winner);
                totalFitness -= winner.Fitness - offset;
            }
        }
    }
}
