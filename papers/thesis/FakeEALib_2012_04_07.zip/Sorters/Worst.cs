﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FakeEALib.Sorters {
    class Worst : ISorter {
        public void Sort(Populations.IPopulation source) {
            ((List<Populations.IIndividual>)source).Sort();
            ((List<Populations.IIndividual>)source).Reverse();
        }
    }
}
