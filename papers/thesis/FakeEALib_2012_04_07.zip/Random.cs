﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FakeEALib {
    public class Random : System.Random {
        private static System.Random Instance = new System.Random();

        private static double? _NextGauss = null;
        public static double Normal() {
            if (_NextGauss.HasValue) {
                var value = _NextGauss.Value;
                _NextGauss = null;
                return value;
            } else {
                double x2pi = Instance.NextDouble() * Math.PI * 2;
                double g2rad = Math.Sqrt(-2.0 * Math.Log(1.0 - Instance.NextDouble()));
                _NextGauss = Math.Sin(x2pi) * g2rad;
                return Math.Cos(x2pi) * g2rad;
            }
        }

        public static double Uniform(double lowest, double highest) {
            return Instance.NextDouble() * (highest - lowest) + lowest;
        }

        public static int Integer(int highest) {
            return Instance.Next(highest);
        }

        public static int Integer(int lowest, int highest) {
            return Instance.Next(lowest, highest + 1);
        }

        public static bool Probability(double prob) {
            return Instance.NextDouble() < prob;
        }
    }
}
