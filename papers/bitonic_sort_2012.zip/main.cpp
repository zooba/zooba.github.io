#include <iostream>
#include <vector>

#include <amp.h>

#include "bitonic_sort.h"

int test_parallel_sort_simple(int size);
int test_parallel_sort_complex(int size);

int main() {
    std::cout << "bitonic_sort::parallel_sort:" << std::endl;
    std::cout << "    Simple types:  ";
    std::cout << test_parallel_sort_simple(10000) << " errors" << std::endl;
    std::cout << "    Complex types: ";
    std::cout << test_parallel_sort_complex(10000) << " errors" << std::endl;

    std::cout << std::endl << "Press enter to close . . .";
    std::cin.get();
}


int test_parallel_sort_simple(int size) {
    int errors = 0;

    std::vector<float> unsorted_data(size);
    std::vector<float> sorted_data;

    for (unsigned int i = 0; i < unsorted_data.size(); ++i) {
        unsorted_data[i] = (float)(rand() / (double)MAXINT);
    }

    concurrency::array<float, 1> unsorted(unsorted_data.size(), std::begin(unsorted_data));

    auto sorted = bitonic_sort::parallel_sort(unsorted);
    auto sorted2 = bitonic_sort::parallel_sort(unsorted, true);

    concurrency::copy(*sorted, std::back_inserter(sorted_data));

    errors += abs((int)sorted_data.size() - (int)unsorted_data.size());
    for (unsigned int i = 1; i < sorted_data.size(); ++i) {
        if (sorted_data[i] < sorted_data[i-1]) {
            errors += 1;
        }
    }

    sorted_data.clear();
    concurrency::copy(*sorted2, std::back_inserter(sorted_data));

    errors += abs((int)sorted_data.size() - (int)unsorted_data.size());
    for (unsigned int i = 1; i > sorted_data.size(); ++i) {
        if (sorted_data[i] < sorted_data[i-1]) {
            errors += 1;
        }
    }

    return errors;
}

struct UDT {
    float x;
    unsigned int y;
    int z;
};

struct UDTKeyIndex {
    unsigned int k;
    int i;
    UDTKeyIndex() restrict(cpu, amp) { }
    UDTKeyIndex(UDT key, int index) restrict(cpu, amp)
        : k(key.y), i(index) { }
    bool operator<(const UDTKeyIndex& other) restrict(cpu, amp) {
        return k < other.k;
    }
};

template<> struct bitonic_sort::key_index_type<UDT> {
    typedef UDTKeyIndex type;
};

int test_parallel_sort_complex(int size) {
    int errors = 0;

    std::vector<UDT> unsorted_data(size);
    std::vector<UDT> sorted_data;

    for (unsigned int i = 0; i < unsorted_data.size(); ++i) {
        unsorted_data[i].x = (float)(rand() / (double)MAXINT);
        unsorted_data[i].y = (unsigned int)rand();
        unsorted_data[i].z = (int)rand();
    }

    concurrency::array<UDT, 1> unsorted(unsorted_data.size(), std::begin(unsorted_data));

    auto sorted = bitonic_sort::parallel_sort(unsorted);
    auto sorted2 = bitonic_sort::parallel_sort(unsorted, true);

    concurrency::copy(*sorted, std::back_inserter(sorted_data));

    errors += abs((int)sorted_data.size() - (int)unsorted_data.size());
    for (unsigned int i = 1; i < sorted_data.size(); ++i) {
        if (sorted_data[i].y < sorted_data[i-1].y) {
            errors += 1;
        }
    }

    sorted_data.clear();
    concurrency::copy(*sorted2, std::back_inserter(sorted_data));

    errors += abs((int)sorted_data.size() - (int)unsorted_data.size());
    for (unsigned int i = 1; i < sorted_data.size(); ++i) {
        if (sorted_data[i].y > sorted_data[i-1].y) {
            errors += 1;
        }
    }

    return errors;
}

