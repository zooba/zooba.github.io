#   Copyright 2010 Steve Dower
# 
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.

from esec.landscape import real
import plugins.PSO

config = {
    'landscape': {
        'class': real.Sphere,
        'size': { 'exact': 30 }
    },
    'system': {
        'definition': r'''
FROM random_pso(length=(cfg.landscape.size.exact),
                lowest=(-x_max), highest=(x_max), \
                zero_velocity=False) \
        SELECT (size) population
FROM population SELECT 1 global_best USING best_only
FROM population SELECT (size) p_bests
YIELD population

BEGIN GENERATION
    JOIN population, p_bests INTO pairs USING tuples
    
    FROM pairs SELECT population USING \ 
         update_velocity(global_best=global_best, w=w, c1=c1, c2=c2), \
         update_position
    
    JOIN population, p_bests INTO pairs USING tuples
    FROM pairs SELECT p_bests USING best_of_tuple
    
    FROM population, global_best SELECT 1 global_best USING best_only
    
    YIELD global_best, population
END GENERATION''',
        'size': 30,
        'x_max': 100,
    },
    'monitor': {
        'report': 'brief+local+time_delta_precise',
        'summary': 'status+brief+best_genome',
        'limits': {
            'generations': 10000,
            'fitness': 0.01,
        }
    },
}

configs = {
    # Use -c PSOTrelea+sphere to use the sphere landscape
    'sphere': {
        'landscape': {
            'class': real.Sphere,
            'size': { 'exact': 30 }
        },
        'system': { 'x_max': 100, },
        'monitor': { 'limits': { 'fitness': 0.01, } },
    },
    # Use -c PSOTrelea+rosenbrock to use the Rosenbrock landscape
    'rosenbrock': {
        'landscape': {
            'class': real.Rosenbrock,
            'size': { 'exact': 30 }
        },
        'system': { 'x_max': 30, },
        'monitor': { 'limits': { 'fitness': 100, } },
    },
    # Use -c PSOTrelea+rastrigin to use the Rastrigin landscape
    'rastrigin': {
        'landscape': {
            'class': real.Rastrigin,
            'size': { 'exact': 30 }
        },
        'system': { 'x_max': 5.12, },
        'monitor': { 'limits': { 'fitness': 100, } },
    },
    # Use -c PSOTrelea+griewank to use the Griewangk landscape
    'griewank': {
        'landscape': {
            'class': real.Griewangk,
            'size': { 'exact': 30 }
        },
        'system': { 'x_max': 600, },
        'monitor': { 'limits': { 'fitness': 0.1, } },
    },
    # Use -c PSOTrelea+f6 to use Schaffer's f6 landscape
    'f6': {
        'landscape': {
            'class': real.SchafferF6,
            'size': { 'exact': 2 }
        },
        'system': { 'x_max': 100, },
        'monitor': { 'limits': { 'fitness': 1e-5, } },
    },
    
    'paramA': { 'system': { 'w': 0.6, 'c1': 1.7, 'c2': 1.7 } },
    'paramB': { 'system': { 'w': 0.729, 'c1': 1.494, 'c2': 1.494 } },
}


pathbase = 'results/PSOTrelea_00'
import os.path
i = 0
while os.path.exists(pathbase):
    i += 1
    pathbase = 'results/PSOTrelea_%02d' % i

settings = ''
settings += 'pathbase="%s";' % pathbase
settings += 'csv=True;low_priority=True;quiet=True'

def batch():
    count = 20
    
    for lscape in ('sphere', 'rosenbrock', 'rastrigin', 'griewank', 'f6'):
        for mode in ('paramA', 'paramB'):
            for pop in (15, 30, 60):
                for _ in xrange(count):
                    yield ([lscape, mode, lscape + "." + mode],
                        'PSOTrelea+noseed+' + lscape + '+' + mode,
                        { 'system': { 'size': pop } },
                        None, None)
